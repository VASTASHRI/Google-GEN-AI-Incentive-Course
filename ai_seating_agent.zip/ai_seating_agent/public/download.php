<?php
// public/download.php
declare(strict_types=1);

// Composer autoload (required for FPDI)
require_once __DIR__ . '/../vendor/autoload.php';

// FPDI main class
use setasign\Fpdi\Fpdi;

$uploadDir = __DIR__ . '/../uploads/';

// ---------------------------
// 1) FORM -> Merge per-room PDFs and download combined PDF
// ---------------------------
if (isset($_POST['download_pdf'])) {

    // Accept optional room-order POST (comma separated ints), else default range
    if (!empty($_POST['room-order'])) {
        $arr = array_filter(array_map('trim', explode(',', $_POST['room-order'])), 'strlen');
        $roomOrder = array_map('intval', $arr);
    } else {
        $roomOrder = range(201, 210);
    }

    // Build list of existing per-room PDF files in the order requested
    $pdfFiles = [];
    $missing = [];
    foreach ($roomOrder as $rn) {
        $filename = "seating_room_{$rn}.pdf"; // match your PdfAgent naming
        $path = $uploadDir . $filename;
        if (file_exists($path) && is_readable($path)) {
            $pdfFiles[] = $path;
        } else {
            $missing[] = $filename;
        }
    }

    if (empty($pdfFiles)) {
        $msg = "No seating PDFs found for the requested rooms.";
        if (!empty($missing)) $msg .= " Missing files: " . implode(', ', $missing);
        die($msg);
    }

    // Optional: include exam date/time from form for filename
    $examDate = $_POST['class-date'] ?? '';
    $t1 = $_POST['class-time1'] ?? '';
    $t2 = $_POST['class-time2'] ?? '';
    $examTime = trim($t1 . ' - ' . $t2, " -");

    // Merge PDFs using FPDI
    try {
        $pdf = new Fpdi();

        foreach ($pdfFiles as $file) {
            // setSourceFile returns number of pages
            $pageCount = $pdf->setSourceFile($file);
            for ($pageNo = 1; $pageNo <= $pageCount; $pageNo++) {
                $tplId = $pdf->importPage($pageNo);
                $size = $pdf->getTemplateSize($tplId);

                // Choose page orientation based on template dimensions
                $orientation = ($size['width'] > $size['height']) ? 'L' : 'P';
                $pdf->AddPage($orientation, [$size['width'], $size['height']]);

                $pdf->useTemplate($tplId);
            }
        }

        // Output filename
        $outName = 'Seating_Arrangement';
        if ($examDate) $outName .= "_{$examDate}";
        if ($examTime) $outName .= "_{$examTime}";
        $outName .= '.pdf';

        // Stream merged PDF to browser (force download)
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="' . basename($outName) . '"');
        // prevent caching
        header('Cache-Control: no-cache, must-revalidate');
        header('Pragma: no-cache');

        $pdf->Output('D', $outName);
        exit;

    } catch (Throwable $e) {
        http_response_code(500);
        die("Failed to merge PDFs: " . $e->getMessage());
    }
}

// ---------------------------
// 2) DOWNLOAD ALL PDFs AS ZIP
// ---------------------------
if (isset($_GET['all'])) {
    $pdfFiles = glob($uploadDir . 'seating_*.pdf');
    if (empty($pdfFiles)) {
        die("No seating PDF files found to ZIP.");
    }

    $zipName = 'all_seating_pdfs.zip';
    $zipPath = $uploadDir . $zipName;
    $zip = new ZipArchive();
    if ($zip->open($zipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== TRUE) {
        die("Failed to create ZIP file.");
    }
    foreach ($pdfFiles as $file) {
        $zip->addFile($file, basename($file));
    }
    $zip->close();

    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="' . $zipName . '"');
    header('Content-Length: ' . filesize($zipPath));
    readfile($zipPath);
    exit;
}

// ---------------------------
// 3) DOWNLOAD SINGLE PDF
// ---------------------------
if (isset($_GET['file'])) {
    $file = basename($_GET['file']);  // sanitize
    $filePath = $uploadDir . $file;

    if (!file_exists($filePath)) {
        die("File not found: " . htmlspecialchars($file));
    }

    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="' . $file . '"');
    header('Content-Length: ' . filesize($filePath));
    readfile($filePath);
    exit;
}

// ---------------------------
// 4) Default: show simple HTML page to trigger form (optional)
// ---------------------------
?>
// ---------------------------
// 4) Default: show simple HTML page to trigger form (optional)
// ---------------------------
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Download Seating PDFs</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <style>
        :root {
            --bg-gradient: linear-gradient(135deg, #0f172a, #1d3557, #3b82f6);
            --card-bg: rgba(15, 23, 42, 0.9);
            --card-border: rgba(148, 163, 184, 0.4);
            --accent: #3b82f6;
            --accent-soft: rgba(59, 130, 246, 0.15);
            --text-main: #f9fafb;
            --text-muted: #9ca3af;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            min-height: 100vh;
            margin: 0;
            font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
            color: var(--text-main);
            background-image: var(--bg-gradient);
            background-attachment: fixed;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
        }

        .shell {
            width: 100%;
            max-width: 780px;
            display: grid;
            grid-template-columns: minmax(0, 3fr) minmax(0, 2fr);
            gap: 20px;
        }

        @media (max-width: 800px) {
            .shell {
                grid-template-columns: minmax(0, 1fr);
            }
        }

        .card {
            padding: 22px 24px;
            border-radius: 18px;
            background:
                radial-gradient(circle at top left, rgba(59,130,246,0.22), transparent 55%),
                radial-gradient(circle at bottom right, rgba(56,189,248,0.16), transparent 50%),
                var(--card-bg);
            border: 1px solid var(--card-border);
            box-shadow: 0 18px 45px rgba(15, 23, 42, 0.75);
            backdrop-filter: blur(20px);
        }

        .card-secondary {
            padding: 20px;
            border-radius: 16px;
            background: var(--card-bg);
            border: 1px solid var(--card-border);
            box-shadow: 0 12px 35px rgba(15, 23, 42, 0.65);
            backdrop-filter: blur(18px);
        }

        .title-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 10px;
            margin-bottom: 12px;
        }

        .title-main {
            font-size: 1.3rem;
            font-weight: 700;
            letter-spacing: 0.03em;
        }

        .subtitle {
            font-size: 0.88rem;
            color: var(--text-muted);
            margin-bottom: 14px;
        }

        .tag {
            font-size: 0.72rem;
            padding: 3px 10px;
            border-radius: 999px;
            background: var(--accent-soft);
            color: #bfdbfe;
        }

        .field {
            margin-bottom: 12px;
        }

        .label {
            display: block;
            font-size: 0.8rem;
            font-weight: 500;
            margin-bottom: 4px;
        }

        input[type="text"],
        input[type="date"],
        input[type="time"] {
            width: 100%;
            padding: 7px 9px;
            border-radius: 10px;
            border: 1px solid rgba(148, 163, 184, 0.6);
            background: rgba(15, 23, 42, 0.92);
            color: var(--text-main);
            font-size: 0.85rem;
        }

        input[type="text"]:focus,
        input[type="date"]:focus,
        input[type="time"]:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 1px rgba(59, 130, 246, 0.6);
        }

        .hint {
            font-size: 0.78rem;
            color: var(--text-muted);
            margin-top: 4px;
        }

        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            padding: 9px 16px;
            border-radius: 999px;
            border: none;
            cursor: pointer;
            font-size: 0.88rem;
            font-weight: 600;
            transition: transform 0.12s ease, box-shadow 0.12s ease, background 0.12s ease;
        }

        .btn-primary {
            background: linear-gradient(135deg, #3b82f6, #6366f1);
            color: white;
            box-shadow: 0 10px 30px rgba(37, 99, 235, 0.55);
        }

        .btn-primary:hover {
            transform: translateY(-1px);
            box-shadow: 0 15px 40px rgba(37, 99, 235, 0.8);
        }

        .btn-ghost {
            background: transparent;
            color: var(--text-muted);
            border: 1px solid rgba(148, 163, 184, 0.6);
        }

        .btn-ghost:hover {
            background: rgba(15, 23, 42, 0.9);
            transform: translateY(-1px);
        }

        .btn-icon {
            font-size: 1rem;
        }

        .row-inline {
            display: flex;
            gap: 8px;
            align-items: center;
        }

        .link-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
            font-size: 0.86rem;
        }

        a {
            color: #93c5fd;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }

        .secondary-title {
            font-size: 1rem;
            font-weight: 600;
            margin-bottom: 6px;
        }

        .chip {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 3px 8px;
            border-radius: 999px;
            background: rgba(15, 23, 42, 0.95);
            border: 1px solid rgba(148, 163, 184, 0.6);
            font-size: 0.75rem;
            color: var(--text-muted);
        }
    </style>
</head>
<body>

<div class="shell">

    <!-- Left: Form for merged PDF -->
    <section class="card">
        <div class="title-row">
            <div>
                <div class="title-main">Download / Merge Seating PDFs</div>
                <div class="subtitle">
                    Build a single combined PDF for invigilators and control room, or keep room-wise files.
                </div>
            </div>
            <span class="tag">Merge &amp; Export</span>
        </div>

        <form method="post" action="">
            <div class="field">
                <label class="label" for="room-order">Room order (optional)</label>
                <input type="text" id="room-order" name="room-order" placeholder="201,202,203">
                <div class="hint">
                    Comma-separated room numbers. If left empty, defaults to <code>201–210</code>.
                </div>
            </div>

            <div class="field">
                <label class="label" for="class-date">Exam date (optional)</label>
                <input type="date" id="class-date" name="class-date">
                <div class="hint">
                    Used in the merged PDF filename (e.g., <code>Seating_Arrangement_2025-11-20.pdf</code>).
                </div>
            </div>

            <div class="field">
                <label class="label">Exam time (optional)</label>
                <div class="row-inline">
                    <input type="time" name="class-time1">
                    <span style="font-size:0.8rem; color:var(--text-muted);">to</span>
                    <input type="time" name="class-time2">
                </div>
                <div class="hint">
                    Also appended to the output filename if provided.
                </div>
            </div>

            <div style="margin-top: 16px; display:flex; gap:10px; flex-wrap:wrap;">
                <button type="submit" name="download_pdf" class="btn btn-primary">
                    <span class="btn-icon">📄</span>
                    <span>Download merged PDF</span>
                </button>
                <button type="button" class="btn btn-ghost" onclick="window.location.href='status.php'">
                    🔙 Back to Status
                </button>
            </div>
        </form>
    </section>

    <!-- Right: Other download options -->
    <aside class="card-secondary">
        <div class="secondary-title">Other download options</div>
        <div class="subtitle">
            Quickly grab all room PDFs as a ZIP, or download a specific room file.
        </div>

        <div class="link-group">
            <a href="?all=1">
                📦 Download ZIP of all saved seating PDFs
            </a>
            <div class="hint">
                This bundles all <code>seating_*.pdf</code> from the uploads folder into a single ZIP.
            </div>

            <div>
                <div class="chip">
                    <span>📁 Single room PDF</span>
                </div>
                <div class="hint" style="margin-top:4px;">
                    Example: <code>?file=seating_room_201.pdf</code><br>
                    Replace <code>201</code> with the room number you need.
                </div>
            </div>

            <div class="hint" style="margin-top:10px;">
                Tip: Use merged PDF for invigilators and use individual room PDFs for hall door display.
            </div>
        </div>
    </aside>

</div>

</body>
</html>
