<?php
// lib/PdfAgent.php (updated)
declare(strict_types=1);

require_once __DIR__ . '/../vendor/autoload.php';
// FPDI autoload optional
if (file_exists(__DIR__ . '/../vendor/setasign/fpdi/src/autoload.php')) {
    require_once __DIR__ . '/../vendor/setasign/fpdi/src/autoload.php';
}

// Ensure FPDF is available
if (!class_exists('\FPDF')) {
    if (file_exists(__DIR__ . '/../FPDF/fpdf.php')) {
        require_once __DIR__ . '/../FPDF/fpdf.php';
    } else {
        throw new \RuntimeException("FPDF not found. Install or add FPDF to the project.");
    }
}

/**
 * SeatingPDF - helper class that builds pages containing one or more room tables.
 * Uses Landscape A4.
 */
class SeatingPDF extends \FPDF
{
    // Create table for a room. $data is array of rows; each row can be assoc or numeric.
    public function RoomTable(array $header, array $data, $roomNo, $examDate = null, $examTime = null)
    {
        // margins and widths chosen to fit Landscape A4
        $this->SetMargins(10, 10);
        $usableWidth = 297 - 20; // A4 landscape width - left/right margins

        // We have 6 columns. Reserve a bit for spacing; compute widths to fit
        $colCount = count($header);
        $colWidth = floor($usableWidth / $colCount);
        // Slight adjustment if too wide
        $widths = array_fill(0, $colCount, $colWidth);

        $this->SetFont('Arial', 'B', 12);
        if ($examDate || $examTime) {
            $left = $examDate ? "Date: {$examDate}" : '';
            $right = $examTime ? "Time: {$examTime}" : '';
            $this->Cell(0, 7, trim($left . '    ' . $right), 0, 1, 'L');
        }

        $this->Cell(0, 8, "Room No. {$roomNo}", 0, 1, 'C');
        $this->SetFont('Arial', 'B', 10);

        // Print header
        foreach ($header as $i => $col) {
            $w = $widths[$i] ?? $colWidth;
            $this->Cell($w, 7, (string)$col, 1, 0, 'C');
        }
        $this->Ln();

        // Print rows
        $this->SetFont('Arial', '', 10);
        foreach ($data as $row) {
            // normalize to numeric list in the same order as header
            $cells = [];
            if (is_array($row) && array_values($row) === $row) {
                $cells = $row; // numeric
            } else {
                // associative: try to map by header keys (L3,R3,L2,R2,L1,R1)
                foreach ($header as $h) {
                    $cells[] = isset($row[$h]) ? $row[$h] : (isset($row[str_replace(' ', '', $h)]) ? $row[str_replace(' ', '', $h)] : '---');
                }
            }

            foreach ($cells as $i => $col) {
                $w = $widths[$i] ?? $colWidth;
                $this->Cell($w, 7, (string)($col ?? '---'), 1, 0, 'C');
            }
            $this->Ln();
        }

        $this->Ln(6);
    }
}

class PdfAgent extends AgentBase
{
    /**
     * run: accepts either allocations array or ['allocations'=>..., 'opts'=>...]
     * Produces ONE combined PDF containing all rooms (multiple tables per page based on opts.perPage)
     * Returns ['combined' => '/path/to/file.pdf']
     */
    public function run($input)
    {
        $allocations = null;
        $opts = [];

        if (is_array($input) && isset($input['allocations'])) {
            $allocations = $input['allocations'];
            $opts = isset($input['opts']) && is_array($input['opts']) ? $input['opts'] : [];
        } elseif (is_array($input)) {
            $allocations = $input;
        } else {
            throw new \InvalidArgumentException("PdfAgent::run expects an array (allocations) or ['allocations'=>..., 'opts'=>...].");
        }

        if (!is_array($allocations)) {
            throw new \InvalidArgumentException("PdfAgent::run received invalid allocations data.");
        }

        $outDir = $opts['outDir'] ?? (__DIR__ . '/../uploads/');
        if (!is_dir($outDir)) @mkdir($outDir, 0755, true);

        $examDate = $opts['examDate'] ?? null;
        $examTime = $opts['examTime'] ?? null;
        $perPage = isset($opts['perPage']) ? max(1, (int)$opts['perPage']) : 2; // tables per page
        $headerOrder = $opts['header'] ?? ['L3','R3','L2','R2','L1','R1'];

        $pdf = new SeatingPDF('L', 'mm', 'A4');
        $pdf->SetAutoPageBreak(true, 10);

        $tableCount = 0;
        foreach ($allocations as $room => $rows) {
            // skip empty
            if (!is_array($rows) || empty($rows)) continue;

            if ($tableCount % $perPage == 0) {
                $pdf->AddPage();
            }

            // Normalize rows to array of numeric rows following headerOrder
            $normalized = [];
            foreach ($rows as $r) {
                $row = [];
                if (is_array($r) && array_values($r) === $r) {
                    // numeric rows - assume already in proper order
                    $row = $r;
                } else {
                    foreach ($headerOrder as $h) {
                        $row[] = isset($r[$h]) ? $r[$h] : (isset($r[strtoupper($h)]) ? $r[strtoupper($h)] : '---');
                    }
                }
                $normalized[] = $row;
            }

            $pdf->RoomTable($headerOrder, $normalized, $room, $examDate, $examTime);
            $tableCount++;
        }

        // final output file
        $ts = date('Ymd_His');
        $outName = ($opts['outName'] ?? "seating_combined_{$ts}.pdf");
        $outPath = rtrim($outDir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $outName;
        $pdf->Output('F', $outPath);

        return ['combined' => $outPath];
    }

    /**
     * Render combined PDF directly from DB room tables and stream to browser.
     * $pdo: PDO connected to output_db
     * $roomOrder: array of room numbers to render (e.g. [201,202,...])
     * $opts: ['examDate'=>string, 'examTime'=>string, 'perPage'=>2]
     */
    public function renderCombinedFromDb(PDO $pdo, array $roomOrder, array $opts = []): void
    {
        $examDate = $opts['examDate'] ?? null;
        $examTime = $opts['examTime'] ?? null;
        $perPage = (int)($opts['perPage'] ?? 2);
        $header = $opts['header'] ?? ['L3','R3','L2','R2','L1','R1'];

        $pdf = new SeatingPDF('L', 'mm', 'A4');
        $pdf->SetAutoPageBreak(true, 10);

        $tableCount = 0;
        foreach ($roomOrder as $roomNo) {
            $tableName = 'room_' . intval($roomNo);
            $stmt = $pdo->query("SELECT L3, R3, L2, R2, L1, R1 FROM `{$tableName}` ORDER BY id LIMIT 5");
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
            if (empty($rows)) continue;

            if ($tableCount % $perPage == 0) {
                $pdf->AddPage();
            }

            // Normalize rows to numeric arrays
            $norm = [];
            foreach ($rows as $r) {
                $row = [];
                foreach ($header as $h) {
                    $row[] = $r[$h] ?? '---';
                }
                $norm[] = $row;
            }

            $pdf->RoomTable($header, $norm, $roomNo, $examDate, $examTime);
            $tableCount++;
        }

        $outName = 'Seating_Arrangement.pdf';
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="' . $outName . '"');
        $pdf->Output('I', $outName);
        exit;
    }
}
