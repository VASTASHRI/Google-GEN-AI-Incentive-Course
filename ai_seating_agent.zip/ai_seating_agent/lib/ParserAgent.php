<?php
// lib/ParserAgent.php
// Robust parser for CSV and Excel files (returns an array of register-number strings)

declare(strict_types=1);

require_once __DIR__ . '/AgentBase.php';

// load composer autoload if present (for PhpSpreadsheet)
if (file_exists(__DIR__ . '/../vendor/autoload.php')) {
    require_once __DIR__ . '/../vendor/autoload.php';
}

use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class ParserAgent extends AgentBase
{
    /**
     * run($filePath) : array of strings (register numbers)
     */
    public function run($filePath): array
    {
        $filePath = (string)$filePath;
        if (!file_exists($filePath) || !is_readable($filePath)) {
            throw new \RuntimeException("File not found or not readable: {$filePath}");
        }

        $ext = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
        $rows = [];

        // Helper to normalize / sanitize a cell value
        $normalize = function ($val) {
            if ($val === null) return null;
            $val = (string)$val;
            // Remove BOM, trim whitespace, collapse internal spaces
            $val = preg_replace('/^\xEF\xBB\xBF/', '', $val);
            $val = trim($val);
            $val = preg_replace('/\s+/', ' ', $val);
            if ($val === '') return null;
            return strtoupper($val);
        };

        // Helper: decide if a given normalized value looks like a register number
        // Adjust the regex if your regno format is different.
        $is_regno = function (string $v): bool {
            // remove separators for checking
            $clean = preg_replace('/[^A-Z0-9]/', '', strtoupper($v));
            // require at least one digit and at least one letter, and length >= 6
            if (strlen($clean) < 6) return false;
            if (!preg_match('/[0-9]/', $clean)) return false;
            if (!preg_match('/[A-Z]/', $clean)) return false;
            // common regno example: 6176AC21UIT001 -> digits + letters + digits, etc.
            // accept if pattern roughly contains both letters and digits
            return true;
        };

        // ---------- CSV ----------
        if (in_array($ext, ['csv'])) {
            $handle = @fopen($filePath, 'r');
            if ($handle === false) {
                throw new \RuntimeException("Unable to open CSV: {$filePath}");
            }

            $rowIndex = 0;
            while (($data = fgetcsv($handle)) !== false) {
                $rowIndex++;
                if (!is_array($data) || count($data) === 0) continue;

                $firstNonEmpty = null;
                $chosen = null;

                // scan columns: prefer one that matches regno pattern
                foreach ($data as $col) {
                    $norm = $normalize($col);
                    if ($norm === null) continue;
                    if ($firstNonEmpty === null) $firstNonEmpty = $norm;
                    if ($is_regno($norm)) {
                        $chosen = $norm;
                        break;
                    }
                }

                if ($chosen === null) $chosen = $firstNonEmpty;
                if ($chosen !== null) $rows[] = $chosen;
            }

            fclose($handle);
            error_log("ParserAgent: CSV parsed " . count($rows) . " candidate rows from {$filePath}");
            return $rows;
        }

        // ---------- Excel (xls/xlsx/xlsm) ----------
        if (in_array($ext, ['xls', 'xlsx', 'xlsm'])) {
            if (!class_exists('\\PhpOffice\\PhpSpreadsheet\\IOFactory')) {
                throw new \RuntimeException("PhpSpreadsheet not available. Run `composer install` in project root.");
            }

            try {
                $spreadsheet = IOFactory::load($filePath);
            } catch (\Throwable $e) {
                throw new \RuntimeException("PhpSpreadsheet failed to load {$filePath}: " . $e->getMessage());
            }

            /** @var Worksheet $sheet */
            $sheet = $spreadsheet->getActiveSheet();
            $highestRow = (int)$sheet->getHighestRow();
            $highestColumnIndex = Coordinate::columnIndexFromString($sheet->getHighestColumn());

            for ($r = 1; $r <= $highestRow; $r++) {
                $firstNonEmpty = null;
                $chosen = null;

                // scan columns left->right
                for ($c = 1; $c <= $highestColumnIndex; $c++) {
                    $colLetter = Coordinate::stringFromColumnIndex($c);
                    $cell = $sheet->getCell($colLetter . $r);
                    $val = $normalize($cell ? $cell->getValue() : null);
                    if ($val === null) continue;
                    if ($firstNonEmpty === null) $firstNonEmpty = $val;
                    if ($is_regno($val)) {
                        $chosen = $val;
                        break;
                    }
                }

                if ($chosen === null) $chosen = $firstNonEmpty;
                if ($chosen !== null) $rows[] = $chosen;
            }

            error_log("ParserAgent: Excel parsed " . count($rows) . " candidate rows from {$filePath}");
            return $rows;
        }

        // ---------- Unknown: try reading as plain text lines ----------
        $content = @file($filePath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if ($content !== false) {
            foreach ($content as $line) {
                $val = $normalize($line);
                if ($val === null) continue;
                $rows[] = $val;
            }
            error_log("ParserAgent: Text parsed " . count($rows) . " rows from {$filePath}");
            return $rows;
        }

        error_log("ParserAgent: No readable rows found for {$filePath}");
        return $rows;
    }
}
