<?php
// public/status.php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

$uploadDir = __DIR__ . '/../uploads/';
$pdfFiles = array_merge(
    glob($uploadDir . 'seating_*.pdf') ?: []
);

// Email status from run_allocation.php (for popup)
$emailStatus = $_GET['email_status'] ?? null;
$emailCount  = isset($_GET['email_count']) ? (int)$_GET['email_count'] : 0;

$popupMessage = '';
if ($emailStatus === 'ok') {
    $popupMessage = "Emails have been sent to {$emailCount} students.";
} elseif ($emailStatus === 'error') {
    $popupMessage = "Error while sending emails. Please check the server logs.";
} elseif ($emailStatus === 'no_emails') {
    $popupMessage = "Allocation completed, but no student emails were found. Check your Excel/CSV email columns or configuration.";
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Seating Allocation Status</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <style>
        :root {
            --bg-gradient: linear-gradient(135deg, #0f172a, #1d3557, #3b82f6);
            --card-bg: rgba(15, 23, 42, 0.95);
            --card-border: rgba(148, 163, 184, 0.45);
            --accent: #3b82f6;
            --accent-soft: rgba(59, 130, 246, 0.18);
            --text-main: #f9fafb;
            --text-muted: #9ca3af;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            min-height: 100vh;
            margin: 0;
            font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
            color: var(--text-main);
            background-image: var(--bg-gradient);
            background-attachment: fixed;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
        }

        .shell {
            width: 100%;
            max-width: 980px;
            display: grid;
            grid-template-columns: minmax(0, 3fr) minmax(0, 2fr);
            gap: 20px;
        }

        @media (max-width: 880px) {
            .shell {
                grid-template-columns: minmax(0, 1fr);
            }
        }

        .card {
            padding: 22px 24px;
            border-radius: 20px;
            background:
                radial-gradient(circle at top left, rgba(59,130,246,0.22), transparent 55%),
                radial-gradient(circle at bottom right, rgba(56,189,248,0.18), transparent 50%),
                var(--card-bg);
            border: 1px solid var(--card-border);
            box-shadow: 0 20px 55px rgba(15, 23, 42, 0.85);
            backdrop-filter: blur(20px);
        }

        .card-secondary {
            padding: 18px 20px;
            border-radius: 18px;
            background: var(--card-bg);
            border: 1px solid var(--card-border);
            box-shadow: 0 14px 40px rgba(15, 23, 42, 0.8);
            backdrop-filter: blur(18px);
        }

        .title-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 10px;
            margin-bottom: 10px;
        }

        .title-main {
            font-size: 1.4rem;
            font-weight: 700;
            letter-spacing: 0.04em;
        }

        .subtitle {
            font-size: 0.88rem;
            color: var(--text-muted);
            margin-bottom: 14px;
        }

        .tag {
            font-size: 0.72rem;
            padding: 3px 10px;
            border-radius: 999px;
            background: var(--accent-soft);
            color: #bfdbfe;
        }

        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            padding: 9px 16px;
            border-radius: 999px;
            border: none;
            cursor: pointer;
            font-size: 0.88rem;
            font-weight: 600;
            transition: transform 0.12s ease, box-shadow 0.12s ease, background 0.12s ease;
            text-decoration: none;
        }

        .btn-primary {
            background: linear-gradient(135deg, #3b82f6, #6366f1);
            color: white;
            box-shadow: 0 10px 30px rgba(37, 99, 235, 0.55);
        }

        .btn-primary:hover {
            transform: translateY(-1px);
            box-shadow: 0 15px 40px rgba(37, 99, 235, 0.8);
        }

        .btn-ghost {
            background: transparent;
            color: var(--text-muted);
            border: 1px solid rgba(148, 163, 184, 0.7);
        }

        .btn-ghost:hover {
            background: rgba(15,23,42,0.96);
            transform: translateY(-1px);
        }

        .btn-icon {
            font-size: 1rem;
        }

        .file-list {
            list-style: none;
            margin-top: 10px;
        }

        .file-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 10px;
            padding: 8px 10px;
            border-radius: 10px;
            border: 1px solid rgba(30,64,175,0.4);
            background: rgba(15,23,42,0.9);
            font-size: 0.86rem;
            margin-bottom: 6px;
        }

        .file-name {
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .file-actions {
            display: flex;
            flex-wrap: wrap;
            gap: 6px;
            font-size: 0.8rem;
        }

        .link-as-btn {
            padding: 4px 8px;
            border-radius: 999px;
            border: 1px solid rgba(148, 163, 184, 0.7);
            background: rgba(15,23,42,0.9);
            color: #bfdbfe;
            text-decoration: none;
        }

        .link-as-btn:hover {
            background: rgba(15,23,42,1);
        }

        .empty-state {
            font-size: 0.9rem;
            color: var(--text-muted);
            padding: 10px 0;
        }

        a {
            color: #93c5fd;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }

        .secondary-title {
            font-size: 1rem;
            font-weight: 600;
            margin-bottom: 6px;
        }

        .footer-links {
            margin-top: 16px;
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            font-size: 0.86rem;
        }
    </style>
</head>
<body>

<script>
<?php if (!empty($popupMessage)): ?>
    alert(<?php echo json_encode($popupMessage); ?>);
<?php endif; ?>
</script>

<div class="shell">

    <!-- Left: PDF list -->
    <section class="card">
        <div class="title-row">
            <div>
                <div class="title-main">Seating Allocation Status</div>
                <div class="subtitle">
                    View and download generated seating PDFs for each room, or grab them all as a ZIP.
                </div>
            </div>
            <span class="tag">Outputs</span>
        </div>

        <div style="margin-bottom: 14px;">
            <a href="download.php?all=1" class="btn btn-primary">
                <span class="btn-icon">📦</span>
                <span>Download All Seating PDFs (ZIP)</span>
            </a>
        </div>

        <h3 style="font-size:1rem; margin-bottom:6px;">Generated Seating PDFs</h3>

        <ul class="file-list">
            <?php if (!empty($pdfFiles)): ?>
                <?php foreach ($pdfFiles as $f): ?>
                    <li class="file-item">
                        <span class="file-name">
                            <?php echo htmlspecialchars(basename($f)); ?>
                        </span>
                        <span class="file-actions">
                            <a class="link-as-btn" href="download.php?file=<?php echo urlencode(basename($f)); ?>">
                                ⬇️ Download
                            </a>
                            <a class="link-as-btn" href="../uploads/<?php echo rawurlencode(basename($f)); ?>" target="_blank">
                                👁️ View
                            </a>
                        </span>
                    </li>
                <?php endforeach; ?>
            <?php else: ?>
                <li class="empty-state">
                    No PDFs generated yet. Run an allocation from the Home page to create seating charts.
                </li>
            <?php endif; ?>
        </ul>
    </section>

    <!-- Right: shortcuts / links -->
    <aside class="card-secondary">
        <div class="secondary-title">Shortcuts</div>
        <div class="subtitle">
            Use these quick actions to move between allocation, downloads, and home.
        </div>

        <div class="footer-links">
            <a href="index.php" class="btn btn-ghost">
                🏠 Back to Home
            </a>
            <a href="download.php" class="btn btn-ghost">
                📄 Merge / Advanced Download
            </a>
        </div>

        <div style="margin-top: 16px; font-size:0.8rem; color:var(--text-muted);">
            • Use the <strong>ZIP</strong> for archiving or sharing with staff.<br>
            • Use individual room PDFs to print and stick on exam hall doors.<br>
            • Return to <strong>Home</strong> to upload new files or re-run allocation.
        </div>
    </aside>

</div>

</body>
</html>
