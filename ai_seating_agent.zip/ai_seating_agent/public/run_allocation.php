<?php
// public/run_allocation.php (updated to include delete/truncate handler + email status)
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

// optional: clear opcode cache during dev
if (function_exists('opcache_reset')) @opcache_reset();

// load composer if present
$vendorAutoload = __DIR__ . '/../vendor/autoload.php';
if (file_exists($vendorAutoload)) require_once $vendorAutoload;

// load configuration
$configFile = __DIR__ . '/../config.php';
if (!file_exists($configFile)) {
    die("Missing config.php at: {$configFile}");
}
$config = include $configFile;

/**
 * DELETE / TRUNCATE handler (trigger by POST delete_output=1)
 * Placed here so it runs before allocation work.
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_output']) && $_POST['delete_output'] == '1') {
    // Build output DB connection settings (fall back to defaults)
    $dbDefault = [
        'host' => '127.0.0.1',
        'dbname' => 'output_db',
        'user' => 'root',
        'pass' => '',
        'charset' => 'utf8mb4'
    ];
    if (!empty($config['db']['output']) && is_array($config['db']['output'])) {
        $outCfg = array_merge($dbDefault, $config['db']['output']);
    } elseif (!empty($config['db']) && is_array($config['db'])) {
        $outCfg = array_merge($dbDefault, $config['db']);
    } else {
        $outCfg = $dbDefault;
    }

    $dsn = "mysql:host={$outCfg['host']};dbname={$outCfg['dbname']};charset={$outCfg['charset']}";
    try {
        $pdo = new PDO($dsn, $outCfg['user'], $outCfg['pass'], [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
    } catch (PDOException $e) {
        http_response_code(500);
        echo "<h2>Failed to connect to output DB</h2><p>" . htmlspecialchars($e->getMessage()) . "</p>";
        exit;
    }

    $truncated = [];
    $errors = [];

    try {
        // Use INFORMATION_SCHEMA for reliable table listing within the current database
        $sql = "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES
                WHERE TABLE_SCHEMA = :schema AND TABLE_NAME LIKE 'room\\_%'";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':schema' => $outCfg['dbname']]);
        $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    } catch (Throwable $e) {
        $tables = [];
        $errors[] = "Error listing tables: " . $e->getMessage();
    }

    if (!empty($tables)) {
        try {
            $pdo->beginTransaction();
            foreach ($tables as $t) {
                try {
                    // Try TRUNCATE first (fast)
                    $pdo->exec("TRUNCATE TABLE `{$t}`");
                    $truncated[] = $t;
                } catch (Throwable $inner) {
                    // Fallback to DELETE if TRUNCATE not permitted
                    try {
                        $pdo->exec("DELETE FROM `{$t}`");
                        $truncated[] = $t . " (deleted rows)";
                    } catch (Throwable $inner2) {
                        $errors[] = "Failed to truncate/delete {$t}: " . $inner2->getMessage();
                    }
                }
            }
            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $errors[] = "Transaction failed: " . $e->getMessage();
        }
    }

    // Delete generated per-room PDFs in uploads folder
    $deletedFiles = [];
    $failedFiles = [];

    $uploadDir = __DIR__ . '/../uploads/';
    if (!is_dir($uploadDir)) {
        $errors[] = "Uploads folder not found at: {$uploadDir}";
    } else {
        foreach (glob($uploadDir . 'seating_*.pdf') as $file) {
            if (is_writable($file)) {
                if (@unlink($file)) {
                    $deletedFiles[] = basename($file);
                } else {
                    $failedFiles[] = basename($file);
                }
            } else {
                // attempt to chmod then delete (best-effort)
                @chmod($file, 0666);
                if (@unlink($file)) {
                    $deletedFiles[] = basename($file);
                } else {
                    $failedFiles[] = basename($file);
                }
            }
        }
    }

    ?>
    <!doctype html>
    <html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Delete Output Result</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
            :root {
                --bg-gradient: linear-gradient(135deg, #0f172a, #1d3557, #ef4444);
                --card-bg: rgba(15, 23, 42, 0.95);
                --card-border: rgba(248, 113, 113, 0.5);
                --text-main: #f9fafb;
                --text-muted: #9ca3af;
                --ok: #22c55e;
                --err: #fecaca;
            }
            * { box-sizing: border-box; margin: 0; padding: 0; }
            body {
                min-height: 100vh;
                margin: 0;
                font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
                color: var(--text-main);
                background-image: var(--bg-gradient);
                background-attachment: fixed;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 24px;
            }
            .shell {
                width: 100%;
                max-width: 900px;
                padding: 22px 24px;
                border-radius: 20px;
                background:
                    radial-gradient(circle at top left, rgba(239,68,68,0.35), transparent 55%),
                    radial-gradient(circle at bottom right, rgba(248,113,113,0.18), transparent 50%),
                    var(--card-bg);
                border: 1px solid var(--card-border);
                box-shadow: 0 22px 60px rgba(15, 23, 42, 0.85);
                backdrop-filter: blur(22px);
            }
            .title-row {
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: 12px;
                margin-bottom: 10px;
            }
            .title-main {
                font-size: 1.4rem;
                font-weight: 700;
                letter-spacing: 0.04em;
            }
            .tag {
                font-size: 0.72rem;
                padding: 3px 10px;
                border-radius: 999px;
                background: rgba(248,113,113,0.22);
                color: #fecaca;
                border: 1px solid rgba(248,113,113,0.7);
            }
            .subtitle {
                font-size: 0.86rem;
                color: var(--text-muted);
                margin-bottom: 14px;
            }
            h4 {
                margin-top: 14px;
                margin-bottom: 6px;
                font-size: 0.95rem;
            }
            ul {
                margin: 4px 0 8px 16px;
                padding-left: 0;
                font-size: 0.85rem;
            }
            li { margin-bottom: 2px; }
            .ok {
                color: var(--ok);
                font-weight: 600;
                margin-bottom: 6px;
            }
            .err { color: var(--err); }
            .footer-links {
                margin-top: 16px;
                display: flex;
                flex-wrap: wrap;
                gap: 10px;
                font-size: 0.86rem;
            }
            .btn-link {
                display: inline-flex;
                align-items: center;
                gap: 4px;
                padding: 7px 12px;
                border-radius: 999px;
                text-decoration: none;
                border: 1px solid rgba(148, 163, 184, 0.7);
                color: #bfdbfe;
                background: rgba(15,23,42,0.9);
                transition: background 0.12s ease, transform 0.12s ease, box-shadow 0.12s ease;
            }
            .btn-link:hover {
                background: rgba(15,23,42,1);
                transform: translateY(-1px);
                box-shadow: 0 10px 25px rgba(15,23,42,0.7);
            }
            .summary-row {
                display: flex;
                flex-wrap: wrap;
                gap: 12px;
                font-size: 0.82rem;
                color: var(--text-muted);
                margin-top: 4px;
            }
            .pill {
                display: inline-flex;
                align-items: center;
                gap: 6px;
                padding: 3px 8px;
                border-radius: 999px;
                font-size: 0.75rem;
                border: 1px solid rgba(148,163,184,0.5);
                background: rgba(15,23,42,0.9);
            }
            .dot-ok {
                width: 7px;
                height: 7px;
                border-radius: 999px;
                background: var(--ok);
            }
            .dot-warn {
                width: 7px;
                height: 7px;
                border-radius: 999px;
                background: #facc15;
            }
        </style>
    </head>
    <body>
        <div class="shell">
            <div class="title-row">
                <div>
                    <div class="title-main">Delete Output Result</div>
                    <div class="subtitle">
                        All selected room tables and generated seating PDFs have been processed. Review the summary below.
                    </div>
                </div>
                <span class="tag">Cleanup run</span>
            </div>

            <p class="ok">✔ Operation completed.</p>

            <div class="summary-row">
                <span class="pill">
                    <span class="dot-ok"></span>
                    <?php echo count($truncated); ?> table(s) cleared
                </span>
                <span class="pill">
                    <span class="dot-ok"></span>
                    <?php echo count($deletedFiles); ?> PDF(s) deleted
                </span>
                <?php if (!empty($errors) || !empty($failedFiles)): ?>
                    <span class="pill">
                        <span class="dot-warn"></span>
                        Some issues occurred
                    </span>
                <?php endif; ?>
            </div>

            <h4>Truncated / cleared tables</h4>
            <?php if (!empty($truncated)): ?>
                <ul>
                    <?php foreach ($truncated as $t): ?>
                        <li><?php echo htmlspecialchars($t); ?></li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p class="subtitle">No <code>room_*</code> tables were found or modified.</p>
            <?php endif; ?>

            <?php if (!empty($errors)): ?>
                <h4 class="err">Errors</h4>
                <ul class="err">
                    <?php foreach ($errors as $er): ?>
                        <li><?php echo htmlspecialchars($er); ?></li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>

            <h4>PDF cleanup</h4>
            <?php if (!empty($deletedFiles)): ?>
                <p>Deleted PDF files:</p>
                <ul>
                    <?php foreach ($deletedFiles as $f): ?>
                        <li><?php echo htmlspecialchars($f); ?></li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p class="subtitle">No <code>seating_*.pdf</code> files were deleted.</p>
            <?php endif; ?>

            <?php if (!empty($failedFiles)): ?>
                <h4 class="err">Failed to delete these files</h4>
                <ul class="err">
                    <?php foreach ($failedFiles as $f): ?>
                        <li><?php echo htmlspecialchars($f); ?></li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>

            <div class="footer-links">
                <a href="index.php" class="btn-link">🏠 Back to Home</a>
                <a href="status.php" class="btn-link">📊 Go to Status Page</a>
            </div>
        </div>
    </body>
    </html>
    <?php
    exit;
}

// ---------------------------
// required library files (allocation flow)
// ---------------------------
$libs = [
    __DIR__ . '/../lib/utils.php',
    __DIR__ . '/../lib/AgentBase.php',
    __DIR__ . '/../lib/ParserAgent.php',
    __DIR__ . '/../lib/DecisionAgent.php',
    __DIR__ . '/../lib/DBAgent.php',
    __DIR__ . '/../lib/PdfAgent.php',
    __DIR__ . '/../lib/EmailAgent.php', // NEW: email agent
];

foreach ($libs as $lib) {
    if (file_exists($lib)) {
        require_once $lib;
    } else {
        die("Required library missing: {$lib}");
    }
}

// sanity: ensure classes exist we will use
foreach (['ParserAgent','PdfAgent'] as $cls) {
    if (!class_exists($cls)) {
        die("Class {$cls} not found. Check lib/{$cls}.php and ensure it defines class {$cls} (no namespace).");
    }
}

// ensure parse_regno exists
if (!function_exists('parse_regno')) {
    die("Missing parse_regno() in lib/utils.php. Please define it (see project README).");
}

// uploads folder (project-level)
$uploadDir = __DIR__ . '/../uploads/';
if (!is_dir($uploadDir)) {
    die("Uploads folder missing: {$uploadDir} — create it and upload CSV/XLSX files into it.");
}

/**
 * Build output DB PDO from config (fall back to defaults)
 */
$dbDefault = [
    'host' => '127.0.0.1',
    'dbname' => 'output_db',
    'user' => 'root',
    'pass' => '',
    'charset' => 'utf8mb4'
];
if (!empty($config['db']['output']) && is_array($config['db']['output'])) {
    $outCfg = array_merge($dbDefault, $config['db']['output']);
} elseif (!empty($config['db']) && is_array($config['db'])) {
    $outCfg = array_merge($dbDefault, $config['db']);
} else {
    $outCfg = $dbDefault;
}

$dsnOut = "mysql:host={$outCfg['host']};dbname={$outCfg['dbname']};charset={$outCfg['charset']}";
try {
    $outputPdo = new PDO($dsnOut, $outCfg['user'], $outCfg['pass'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    echo "<h2>Failed to connect to output DB</h2><p>" . htmlspecialchars($e->getMessage()) . "</p>";
    exit;
}

// ---------------------------
// gather input files (Excel/CSV) - parser will read them
// ---------------------------
$files = array_merge(
    glob($uploadDir . '*.csv') ?: [],
    glob($uploadDir . '*.xlsx') ?: [],
    glob($uploadDir . '*.xls') ?: []
);
if (empty($files)) {
    die("No input files found in uploads directory: {$uploadDir}");
}

// ---------------------------
// parse files (using ParserAgent)
// build $studentsByTable: key = filename (basename), value = array of regnos
// ---------------------------
$parser = new ParserAgent();
$studentsByTable = []; // filename => [regno, ...]
$unparsable = [];
$totalInputRows = 0;

foreach ($files as $f) {
    try {
        $rows = $parser->run($f);
    } catch (Throwable $e) {
        error_log("ParserAgent failed on {$f}: " . $e->getMessage());
        continue;
    }

    // rows may be scalar list or rows of arrays - normalize to regno strings
    $basename = basename($f);
    $studentsByTable[$basename] = [];

    if (!is_array($rows) || count($rows) === 0) {
        error_log("ParserAgent returned no rows for {$f}");
        continue;
    }

    foreach ($rows as $i => $row) {
        $totalInputRows++;
        $regno = null;
        if (is_string($row) || is_numeric($row)) {
            $regno = trim((string)$row);
        } elseif (is_array($row)) {
            // try common keys
            $possibleKeys = ['register_number','regno','reg_no','0','Register','REGNO','REGISTER_NUMBER'];
            foreach ($possibleKeys as $k) {
                if (array_key_exists($k, $row) && trim((string)$row[$k]) !== '') {
                    $regno = trim((string)$row[$k]);
                    break;
                }
            }
            if ($regno === null) {
                // first non-empty cell
                foreach ($row as $v) {
                    if (trim((string)$v) !== '') {
                        $regno = trim((string)$v);
                        break;
                    }
                }
            }
        }

        if ($regno === null || $regno === '') {
            error_log("ParserAgent: skipping empty row index {$i} from file {$f}");
            continue;
        }

        $regnoNormalized = strtoupper(trim($regno));

        // parse register number for sanity (but we still store raw regno)
        try {
            $parsed = parse_regno($regnoNormalized);
        } catch (Throwable $e) {
            $parsed = null;
            error_log("parse_regno() threw for '{$regnoNormalized}': " . $e->getMessage());
        }

        if ($parsed && isset($parsed['dept']) && isset($parsed['year'])) {
            // accept - push into table's list
            $studentsByTable[$basename][] = $regnoNormalized;
        } else {
            // still keep unparsable as well for diagnostics, but don't include them in allocation
            if (count($unparsable) < 20) $unparsable[] = $regnoNormalized;
            error_log("Unparsable regno '{$regnoNormalized}' from file {$f}");
        }
    }
}

error_log("Total input rows: {$totalInputRows}, tables parsed: " . count($studentsByTable));

// remove any empty file groups
foreach ($studentsByTable as $k => $list) {
    if (empty($list)) unset($studentsByTable[$k]);
}

if (empty($studentsByTable)) {
    $msg = "No valid students parsed from input files. ";
    if (!empty($unparsable)) $msg .= "Example unparsable values: " . implode(', ', $unparsable);
    error_log($msg);
    die($msg);
}

// ---------------------------
// helper functions for allocation & DB writes
// ---------------------------

$conflictingDepartments = [
    'UIT' => ['UCS'],
    'UME' => ['UCE'],
    'UBM' => ['UBT'],
    'UEE' => ['UCE']
];

// create room table if missing
function createRoomTable(PDO $pdo, int $roomNo) {
    $table = "room_" . intval($roomNo);
    $sql = "CREATE TABLE IF NOT EXISTS `{$table}` (
                id INT PRIMARY KEY AUTO_INCREMENT,
                L3 VARCHAR(50) DEFAULT NULL, R3 VARCHAR(50) DEFAULT NULL,
                L2 VARCHAR(50) DEFAULT NULL, R2 VARCHAR(50) DEFAULT NULL,
                L1 VARCHAR(50) DEFAULT NULL, R1 VARCHAR(50) DEFAULT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    $pdo->exec($sql);

    // ensure at least 5 rows exist (we rely on 5 rows per room)
    $stmt = $pdo->query("SELECT COUNT(*) as cnt FROM `{$table}`");
    $cnt = (int)$stmt->fetchColumn();
    if ($cnt < 5) {
        // insert missing rows (auto-increment id will be assigned)
        for ($i = $cnt + 1; $i <= 5; $i++) {
            // insert a row with NULLs for all columns
            $pdo->exec("INSERT INTO `{$table}` (L3) VALUES (NULL)");
        }
    }
}

// insert into room by id and column (column must be one of L3,R3,L2,R2,L1,R1)
function insertIntoRoomWithId(PDO $pdo, int $roomNo, int $id, string $column, string $regNo) {
    $allowed = ['L3','R3','L2','R2','L1','R1'];
    if (!in_array($column, $allowed)) throw new InvalidArgumentException("Invalid column {$column}");
    $table = 'room_' . intval($roomNo);

    // Try updating the row id; if none updated, fallback to inserting a row (best-effort)
    $sql = "UPDATE `{$table}` SET `{$column}` = :reg WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':reg' => $regNo, ':id' => $id]);

    if ($stmt->rowCount() === 0) {
        // fallback insert: insert with this column value
        $insSql = "INSERT INTO `{$table}` (`{$column}`) VALUES (:val)";
        $ins = $pdo->prepare($insSql);
        $ins->execute([':val' => $regNo]);
    }
}

// allocate seating column-wise (left columns L1,L2,L3 and right columns R1,R2,R3) into rooms sequentially
function allocateSeating(PDO $pdo, array $studentsLeft, array $studentsRight, array &$roomOrder, int &$currentRoomIndex) {
    $leftColumns = ['L1','L2','L3'];
    $rightColumns = ['R1','R2','R3'];
    $leftIndex = 0;
    $rightIndex = 0;
    $maxRows = 5;

    while ($leftIndex < count($studentsLeft) || $rightIndex < count($studentsRight)) {
        // ensure currentRoomIndex is valid
        if (!isset($roomOrder[$currentRoomIndex])) {
            $last = end($roomOrder);
            $roomOrder[] = (int)$last + 1;
        }

        $roomNo = (int)$roomOrder[$currentRoomIndex];
        createRoomTable($pdo, $roomNo);

        // allocate left side column-wise
        for ($col = 0; $col < 3 && $leftIndex < count($studentsLeft); $col++) {
            for ($row = 1; $row <= $maxRows && $leftIndex < count($studentsLeft); $row++) {
                $column = $leftColumns[$col];
                insertIntoRoomWithId($pdo, $roomNo, $row, $column, $studentsLeft[$leftIndex]);
                $leftIndex++;
            }
        }

        // allocate right side column-wise
        for ($col = 0; $col < 3 && $rightIndex < count($studentsRight); $col++) {
            for ($row = 1; $row <= $maxRows && $rightIndex < count($studentsRight); $row++) {
                $column = $rightColumns[$col];
                insertIntoRoomWithId($pdo, $roomNo, $row, $column, $studentsRight[$rightIndex]);
                $rightIndex++;
            }
        }

        // move to next room
        $currentRoomIndex++;
        if ($currentRoomIndex >= count($roomOrder)) {
            // extend room order by incrementing last room number
            $last = end($roomOrder);
            $roomOrder[] = (int)$last + 1;
        }
    }
}

// Scenario 1: single table — seating order R1, L1, R2, L2, R3, L3
function allocateSeatsScenario1(PDO $pdo, array $students, array &$roomOrder) {
    $seatingOrder = ['R1','L1','R2','L2','R3','L3'];
    $roomIndex = 0;
    $colIndex = 0;
    $rowId = 1;
    $maxRows = 5;

    foreach ($students as $student) {
        if (!isset($roomOrder[$roomIndex])) {
            $last = end($roomOrder);
            $roomOrder[] = (int)$last + 1;
        }
        $roomNo = (int)$roomOrder[$roomIndex];
        createRoomTable($pdo, $roomNo);

        $column = $seatingOrder[$colIndex];
        insertIntoRoomWithId($pdo, $roomNo, $rowId, $column, $student);

        $rowId++;
        if ($rowId > $maxRows) {
            $rowId = 1;
            $colIndex++;
            if ($colIndex >= count($seatingOrder)) {
                // move to next room and reset column index
                $colIndex = 0;
                $roomIndex++;
                if ($roomIndex >= count($roomOrder)) {
                    $last = end($roomOrder);
                    $roomOrder[] = (int)$last + 1;
                }
            }
        }
    }

    error_log("Scenario1: allocated " . count($students) . " students.");
}

// Scenario 2: pair tables, avoid conflicts, use allocateSeating for left/right
function allocateSeatsScenario2(PDO $pdo, array $studentsByTable, array &$roomOrder) {
    $tables = array_keys($studentsByTable);
    $currentRoomIndex = 0;
    for ($i = 0; $i < count($tables); $i += 2) {
        $leftTable = $tables[$i];
        $studentsLeft = $studentsByTable[$leftTable];

        $rightTable = $tables[$i+1] ?? null;
        $studentsRight = $rightTable ? $studentsByTable[$rightTable] : [];

        // assign by reference correctly: ensure $currentRoomIndex is a variable
        allocateSeating($pdo, $studentsLeft, $studentsRight, $roomOrder, $currentRoomIndex);
    }
    error_log("Scenario2: allocated for " . count($tables) . " tables.");
}

// Scenario 3: similar to 2 but used when table count is 2 and depts differ or for general pairing
function allocateSeatsScenario3(PDO $pdo, array $studentsByTable, array &$roomOrder) {
    // reuse allocateSeatsScenario2 behavior (pair wise)
    allocateSeatsScenario2($pdo, $studentsByTable, $roomOrder);
    error_log("Scenario3: allocated (paired tables).");
}

// ---------------------------
// Determine room order (POST or config or default)
$roomOrder = [];
if (!empty($_POST['room-order'])) {
    $inputOrder = trim($_POST['room-order']);
    $roomOrder = array_filter(array_map('trim', explode(',', $inputOrder)), 'strlen');
    $roomOrder = array_map('intval', $roomOrder);
    if (empty($roomOrder)) {
        die("Invalid room order provided.");
    }
} elseif (!empty($config['rooms']) && is_array($config['rooms']) && count($config['rooms']) > 0) {
    // config may contain 'room_201' or 201; normalise later
    $roomOrder = array_values($config['rooms']);
} else {
    $roomOrder = [201,202,203,204,205,206,207,208,209,210];
}

// --- Normalise room order: convert entries like 'room_201' or 'room-201' or '201' to integer 201 ---
foreach ($roomOrder as $k => $r) {
    if (is_string($r)) {
        if (preg_match('/\broom[_-]?(\d+)\b/i', $r, $m)) {
            $roomOrder[$k] = (int)$m[1];
            continue;
        }
    }
    $roomOrder[$k] = (int)$r;
}
// reindex and remove duplicates
$roomOrder = array_values(array_unique($roomOrder));

// ensure room tables exist initially
foreach ($roomOrder as $r) createRoomTable($outputPdo, intval($r));

// ---------------------------
// Determine scenario selection based on parsed input files (studentsByTable)
// ---------------------------
$tables = array_keys($studentsByTable);
$numTables = count($tables);

// compute department codes per table using parse_regno of first regno in each table
$departmentCodes = [];
foreach ($studentsByTable as $tbl => $list) {
    $first = $list[0] ?? null;
    if ($first) {
        try {
            $p = parse_regno($first);
            $departmentCodes[$tbl] = $p['dept'] ?? substr($first, 12, 3);
        } catch (Throwable $e) {
            $departmentCodes[$tbl] = substr($first, 12, 3);
        }
    } else {
        $departmentCodes[$tbl] = null;
    }
}

// Branch scenarios
if ($numTables === 1) {
    // scenario 1: single file
    $students = array_values($studentsByTable)[0];
    allocateSeatsScenario1($outputPdo, $students, $roomOrder);
} elseif ($numTables === 2) {
    // if same department -> scenario4 (special handling) else scenario3
    $t0 = $tables[0]; $t1 = $tables[1];
    if (!empty($departmentCodes[$t0]) && $departmentCodes[$t0] === $departmentCodes[$t1]) {
        // scenario 4 logic — prioritize final years on left etc.
        // For simplicity here: put file0 students on left (L cols) and file1 students on right
        $currentRoomIndex = 0;
        allocateSeating($outputPdo, $studentsByTable[$t0], $studentsByTable[$t1], $roomOrder, $currentRoomIndex);
    } else {
        allocateSeatsScenario3($outputPdo, $studentsByTable, $roomOrder);
    }
} else {
    $uniqueDepts = array_values(array_unique(array_filter($departmentCodes)));
    if (count($uniqueDepts) === 1) {
        // scenario 4: all same department -> treat as final-year prioritization
        // For now: allocate first table left, others right (simple prioritization)
        $firstTable = $tables[0];
        $leftStudents = $studentsByTable[$firstTable];
        // merge remaining as right
        $rightStudents = [];
        for ($i = 1; $i < count($tables); $i++) {
            $rightStudents = array_merge($rightStudents, $studentsByTable[$tables[$i]]);
        }
        $currentRoomIndex = 0;
        allocateSeating($outputPdo, $leftStudents, $rightStudents, $roomOrder, $currentRoomIndex);
    } else {
        allocateSeatsScenario2($outputPdo, $studentsByTable, $roomOrder);
    }
}

// ---------------------------
// Build allocations array from output DB room tables (read up to 5 rows per room)
// Then call PdfAgent->run to create a single combined PDF saved to uploads directory.
// ---------------------------
$allocations = [];
foreach ($roomOrder as $roomNo) {
    $table = 'room_' . intval($roomNo);
    // check if table exists
    try {
        $stmt = $outputPdo->query("SHOW TABLES LIKE " . $outputPdo->quote($table));
        $found = $stmt->fetchColumn();
        if (!$found) continue;
    } catch (Throwable $e) {
        continue;
    }

    // fetch up to 5 rows ordered by id
    try {
        $stmt = $outputPdo->query("SELECT id, L3, R3, L2, R2, L1, R1 FROM `{$table}` ORDER BY id LIMIT 5");
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        if (!empty($rows)) {
            // convert to format expected by PdfAgent: array of rows where each row is assoc with L3..R1
            $roomRows = [];
            foreach ($rows as $r) {
                $roomRows[] = [
                    'L3' => $r['L3'] ?? '---',
                    'R3' => $r['R3'] ?? '---',
                    'L2' => $r['L2'] ?? '---',
                    'R2' => $r['R2'] ?? '---',
                    'L1' => $r['L1'] ?? '---',
                    'R1' => $r['R1'] ?? '---'
                ];
            }
            $allocations["room_{$roomNo}"] = $roomRows;
        }
    } catch (Throwable $e) {
        error_log("Failed to read {$table}: " . $e->getMessage());
        continue;
    }
}

// Generate combined PDF file (non-fatal)
$result = null;
try {
    $pdfAgent = new PdfAgent();
    $opts = [
        'examDate' => $_POST['exam_date'] ?? ($_GET['exam_date'] ?? null),
        'examTime' => $_POST['exam_time'] ?? ($_GET['exam_time'] ?? null),
        'perPage' => (int)($config['pdf']['perPage'] ?? 2),
        'outDir' => $uploadDir,
        'outName' => $config['pdf']['outName'] ?? null
    ];
    if (!empty($allocations)) {
        $result = $pdfAgent->run(['allocations' => $allocations, 'opts' => $opts]);
        error_log("PdfAgent saved combined PDF: " . ($result['combined'] ?? 'n/a'));
    } else {
        error_log("No allocations available to create PDF.");
    }
} catch (Throwable $e) {
    error_log("PdfAgent error: " . $e->getMessage());
}

// ---------------------------
// OPTIONAL EMAIL SENDING + STATUS FOR POPUP
// ---------------------------
$emailStatus = 'none';
$emailCount  = 0;

$sendEmails = isset($_POST['send_emails']) && $_POST['send_emails'] === '1';

if ($sendEmails && class_exists('EmailAgent')) {
    // 1) Build regno -> room/seat map from $allocations
    $studentSeats = []; // REGNO_UPPER => ['regno','room','seat']
    foreach ($allocations as $roomName => $rows) {
        foreach ($rows as $rowIdx => $row) {
            foreach (['L3','R3','L2','R2','L1','R1'] as $col) {
                $reg = $row[$col] ?? null;
                if (!$reg || $reg === '---') continue;
                $key = strtoupper(trim($reg));
                $studentSeats[$key] = [
                    'regno' => trim($reg),
                    'room'  => $roomName,
                    'seat'  => $col . '-' . ($rowIdx + 1), // e.g. L1-3
                ];
            }
        }
    }

    // 2) Load regno -> email mapping from uploads/emails.csv (simple approach)
    $emailMap = [];
    $emailsCsv = $uploadDir . 'emails.csv';
    if (file_exists($emailsCsv)) {
        if (($fh = fopen($emailsCsv, 'r')) !== false) {
            while (($row = fgetcsv($fh)) !== false) {
                if (count($row) < 2) continue;
                $reg = strtoupper(trim($row[0]));
                $em  = trim($row[1]);
                if ($reg && filter_var($em, FILTER_VALIDATE_EMAIL)) {
                    $emailMap[$reg] = $em;
                }
            }
            fclose($fh);
        }
    }

    // 3) Optional fallback: build email as REGNO@domain if config has 'email_domain'
    $domain = $config['email_domain'] ?? null; // e.g. 'college.edu'

    $studentEmails = []; // each: ['email','regno','room','seat']
    foreach ($studentSeats as $key => $info) {
        $email = $emailMap[$key] ?? null;
        if (!$email && $domain) {
            $local = preg_replace('/[^A-Z0-9]/i', '', $info['regno']);
            if ($local !== '') {
                $email = strtolower($local . '@' . $domain);
            }
        }
        if (!$email) continue; // skip students without any email
        $studentEmails[] = [
            'email' => $email,
            'regno' => $info['regno'],
            'room'  => $info['room'],
            'seat'  => $info['seat'],
        ];
    }

    if (!empty($studentEmails)) {
        // 4) Decide attachments: prefer combined PDF, else per-room PDFs
        $attachments = [];
        if (is_array($result) && !empty($result['combined']) && file_exists($result['combined'])) {
            $attachments[] = $result['combined'];
        } else {
            foreach (glob($uploadDir . 'seating_*.pdf') as $pdfFile) {
                $attachments[] = $pdfFile;
            }
        }

        try {
            $emailAgent = new EmailAgent($config);
            $emailAgent->run($studentEmails, $attachments);
            $emailStatus = 'ok';
            $emailCount  = count($studentEmails);
            error_log("EmailAgent: attempted to send {$emailCount} emails.");
        } catch (Throwable $e) {
            $emailStatus = 'error';
            $emailCount  = count($studentEmails);
            error_log("EmailAgent error: " . $e->getMessage());
        }
    } else {
        $emailStatus = 'no_emails';
        $emailCount  = 0;
        error_log("Email sending: no student emails resolved from emails.csv/domain.");
    }
}

// redirect back to status page WITH email status
$query = http_build_query([
    'email_status' => $emailStatus,
    'email_count'  => $emailCount,
]);
header('Location: status.php?' . $query);
exit;
