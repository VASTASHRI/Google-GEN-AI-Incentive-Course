<?php
// index.php
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>AI Exam Seating Agent</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <style>
        :root {
            --bg-gradient: linear-gradient(135deg, #0f172a, #1d3557, #3b82f6);
            --card-bg: rgba(15, 23, 42, 0.88);
            --card-border: rgba(148, 163, 184, 0.4);
            --accent: #3b82f6;
            --accent-soft: rgba(59, 130, 246, 0.15);
            --text-main: #f9fafb;
            --text-muted: #9ca3af;
            --danger: #ef4444;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            min-height: 100vh;
            margin: 0;
            font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
            color: var(--text-main);
            background-image: var(--bg-gradient);
            background-attachment: fixed;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
        }

        .app-shell {
            width: 100%;
            max-width: 1080px;
            display: grid;
            grid-template-columns: minmax(0, 3fr) minmax(0, 2fr);
            gap: 24px;
        }

        @media (max-width: 900px) {
            .app-shell {
                grid-template-columns: minmax(0, 1fr);
            }
        }

        .hero-card {
            padding: 24px 28px;
            border-radius: 20px;
            background:
                radial-gradient(circle at top left, rgba(59,130,246,0.25), transparent 55%),
                radial-gradient(circle at bottom right, rgba(56,189,248,0.18), transparent 50%),
                var(--card-bg);
            border: 1px solid var(--card-border);
            box-shadow: 0 18px 55px rgba(15, 23, 42, 0.7);
            backdrop-filter: blur(20px);
        }

        .hero-header {
            display: flex;
            align-items: center;
            gap: 16px;
            margin-bottom: 16px;
        }

        .hero-icon {
            width: 52px;
            height: 52px;
            border-radius: 16px;
            background: radial-gradient(circle at 30% 30%, #facc15, #f97316);
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 10px 30px rgba(248, 250, 252, 0.25);
            flex-shrink: 0;
        }

        .hero-icon span {
            font-size: 28px;
        }

        .hero-title {
            font-size: 1.6rem;
            font-weight: 700;
            letter-spacing: 0.04em;
        }

        .hero-subtitle {
            font-size: 0.95rem;
            color: var(--text-muted);
        }

        .hero-badges {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin-top: 10px;
        }

        .badge {
            font-size: 0.75rem;
            padding: 4px 10px;
            border-radius: 999px;
            border: 1px solid rgba(148, 163, 184, 0.5);
            background: rgba(15,23,42,0.7);
            display: inline-flex;
            align-items: center;
            gap: 6px;
            color: var(--text-muted);
        }

        .badge-dot {
            width: 7px;
            height: 7px;
            border-radius: 50%;
            background: #22c55e;
        }

        .steps {
            margin-top: 18px;
            display: flex;
            flex-direction: column;
            gap: 10px;
            font-size: 0.9rem;
        }

        .step {
            display: flex;
            align-items: flex-start;
            gap: 10px;
        }

        .step-number {
            width: 20px;
            height: 20px;
            border-radius: 999px;
            background: rgba(148, 163, 184, 0.3);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.75rem;
            font-weight: 600;
        }

        .step-title {
            font-weight: 600;
            margin-bottom: 2px;
        }

        .step-text {
            color: var(--text-muted);
            font-size: 0.86rem;
        }

        .hero-footer {
            margin-top: 18px;
            display: flex;
            justify-content: space-between;
            gap: 12px;
            align-items: center;
            font-size: 0.8rem;
            color: var(--text-muted);
        }

        .hero-footer strong {
            color: var(--accent);
        }

        .hero-progress {
            position: relative;
            flex: 1;
            height: 4px;
            border-radius: 999px;
            background: rgba(30, 64, 175, 0.5);
            overflow: hidden;
        }

        .hero-progress span {
            position: absolute;
            inset: 0;
            width: 60%;
            background: linear-gradient(to right, #22c55e, #a3e635);
            border-radius: 999px;
        }

        .panel-column {
            display: flex;
            flex-direction: column;
            gap: 16px;
        }

        .panel-card {
            padding: 18px 20px;
            border-radius: 18px;
            background: var(--card-bg);
            border: 1px solid var(--card-border);
            box-shadow: 0 12px 35px rgba(15, 23, 42, 0.65);
            backdrop-filter: blur(18px);
        }

        .panel-title-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 8px;
            margin-bottom: 8px;
        }

        .panel-title {
            font-size: 1rem;
            font-weight: 600;
        }

        .panel-tag {
            font-size: 0.72rem;
            padding: 2px 9px;
            border-radius: 999px;
            background: var(--accent-soft);
            color: #bfdbfe;
        }

        .panel-sub {
            font-size: 0.8rem;
            color: var(--text-muted);
            margin-bottom: 10px;
        }

        .field-label {
            font-size: 0.82rem;
            font-weight: 500;
            margin-bottom: 6px;
        }

        .file-input-wrap {
            margin-bottom: 10px;
        }

        input[type="file"] {
            width: 100%;
            padding: 8px;
            border-radius: 10px;
            border: 1px dashed rgba(148, 163, 184, 0.7);
            background: rgba(15, 23, 42, 0.9);
            color: var(--text-main);
            font-size: 0.85rem;
        }

        input[type="file"]::file-selector-button {
            background: var(--accent);
            border: none;
            color: white;
            padding: 6px 12px;
            border-radius: 8px;
            cursor: pointer;
            margin-right: 8px;
            font-size: 0.8rem;
        }

        input[type="file"]::file-selector-button:hover {
            filter: brightness(1.1);
        }

        .hint {
            font-size: 0.78rem;
            color: var(--text-muted);
            margin-top: 4px;
        }

        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            padding: 9px 16px;
            border-radius: 999px;
            border: none;
            cursor: pointer;
            font-size: 0.88rem;
            font-weight: 600;
            transition: transform 0.12s ease, box-shadow 0.12s ease, background 0.12s ease;
        }

        .btn-primary {
            background: linear-gradient(135deg, #3b82f6, #6366f1);
            color: white;
            box-shadow: 0 10px 30px rgba(37, 99, 235, 0.5);
        }

        .btn-primary:hover {
            transform: translateY(-1px);
            box-shadow: 0 15px 40px rgba(37, 99, 235, 0.7);
        }

        .btn-ghost {
            background: transparent;
            color: var(--text-muted);
            border: 1px solid rgba(148, 163, 184, 0.6);
        }

        .btn-ghost:hover {
            background: rgba(15, 23, 42, 0.9);
            transform: translateY(-1px);
        }

        .btn-danger {
            background: linear-gradient(135deg, #ef4444, #b91c1c);
            color: #fee2e2;
            box-shadow: 0 10px 30px rgba(239, 68, 68, 0.55);
        }

        .btn-danger:hover {
            transform: translateY(-1px);
            box-shadow: 0 15px 40px rgba(239, 68, 68, 0.8);
        }

        .btn-icon {
            font-size: 1.05rem;
        }

        .form-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 10px;
            margin-top: 12px;
            flex-wrap: wrap;
        }

        .status-link-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 8px;
            margin-top: 8px;
        }

        .status-pill {
            font-size: 0.75rem;
            padding: 3px 8px;
            border-radius: 999px;
            background: rgba(22, 163, 74, 0.25);
            color: #bbf7d0;
            border: 1px solid rgba(34, 197, 94, 0.6);
        }

        a {
            color: #93c5fd;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>

    <script>
        function confirmDeleteOutput() {
            return confirm("This will TRUNCATE all room_* tables and delete seating_*.pdf — this cannot be undone. Proceed?");
        }
    </script>
</head>
<body>

<div class="app-shell">

    <!-- LEFT: Overview / description -->
    <section class="hero-card">
        <div class="hero-header">
            <div class="hero-icon">
                <span>📚</span>
            </div>
            <div>
                <div class="hero-title">AI Exam Seating Agent</div>
                <div class="hero-subtitle">
                    Automate mixed-department seating allocation, generate PDFs, and keep your exam halls organized.
                </div>
            </div>
        </div>

        <div class="hero-badges">
            <span class="badge"><span class="badge-dot"></span> Conflict-aware seating</span>
            <span class="badge">🪑 Room-wise charts</span>
            <span class="badge">⚙️ Runs from uploaded Excel/CSV</span>
        </div>

        <div class="steps">
            <div class="step">
                <div class="step-number">1</div>
                <div>
                    <div class="step-title">Upload input files</div>
                    <div class="step-text">
                        Upload one or more <strong>.xls, .xlsx, .csv</strong> files with register numbers in column A.
                    </div>
                </div>
            </div>
            <div class="step">
                <div class="step-number">2</div>
                <div>
                    <div class="step-title">Run allocation</div>
                    <div class="step-text">
                        The agent applies your rules (departments, years, columns) and fills room tables automatically.
                    </div>
                </div>
            </div>
            <div class="step">
                <div class="step-number">3</div>
                <div>
                    <div class="step-title">View / reset results</div>
                    <div class="step-text">
                        Download room PDFs from the status page or reset everything with a single click.
                    </div>
                </div>
            </div>
        </div>

        <div class="hero-footer">
            <div>Status: <strong>Ready</strong></div>
            <div class="hero-progress"><span></span></div>
        </div>
    </section>

    <!-- RIGHT: Functional panels -->
    <section class="panel-column">

        <!-- Upload panel (keeps your upload.php + files[] field) -->
        <div class="panel-card">
            <div class="panel-title-row">
                <div class="panel-title">Step 1 — Upload Excel / CSV files</div>
                <span class="panel-tag">Inputs</span>
            </div>
            <div class="panel-sub">
                Choose one or more department-wise files. Allowed extensions: <code>.xls</code>, <code>.xlsx</code>, <code>.csv</code>.
            </div>

            <form action="upload.php" method="post" enctype="multipart/form-data">
                <label class="field-label">Select files</label>
                <div class="file-input-wrap">
                    <input type="file" name="files[]" multiple accept=".xlsx,.xls,.csv">
                </div>
                <div class="hint">
                    Max size is controlled by <code>upload_max_filesize</code> and <code>post_max_size</code> in php.ini.
                </div>

                <div class="form-row">
                    <button type="submit" class="btn btn-primary">
                        <span class="btn-icon">⬆️</span>
                        <span>Upload Files</span>
                    </button>
                    <button type="button" class="btn btn-ghost" onclick="location.reload()">
                        🔄 Refresh
                    </button>
                </div>
            </form>
        </div>

        <!-- Start allocation panel (keeps your run_allocation.php POST) -->
        <div class="panel-card">
    <div class="panel-title-row">
        <div class="panel-title">Step 2 — Start Seating Allocation</div>
        <span class="panel-tag">Agent Run</span>
    </div>
    <div class="panel-sub">
        Trigger the seating engine. It will read the uploaded files, compute allocations, update DB tables, and generate PDFs.
    </div>

    <form action="run_allocation.php" method="post">
        <!-- NEW: send emails checkbox -->
        <div style="font-size:0.82rem; color:var(--text-muted); margin-bottom:8px; display:flex; gap:6px; align-items:flex-start;">
            <input type="checkbox"
                   id="send_emails"
                   name="send_emails"
                   value="1"
                   style="margin-top:2px;">
            <label for="send_emails">
                Also send seat-allotment <strong>emails</strong> to students using
                the register number &amp; email from the uploaded Excel/CSV files.
            </label>
        </div>

        <div class="form-row">
            <button type="submit" class="btn btn-primary">
                <span class="btn-icon">⚙️</span>
                <span>Start Allocation</span>
            </button>
        </div>
    </form>
</div>


        <!-- Status panel (keeps your status.php link) -->
        <div class="panel-card">
            <div class="panel-title-row">
                <div class="panel-title">Step 3 — View Status & PDFs</div>
                <span class="panel-tag">Outputs</span>
            </div>
            <div class="panel-sub">
                Open the status page to see generated seating PDFs, download them individually or as a ZIP.
            </div>

            <div class="status-link-row">
                <a href="status.php" class="btn btn-primary">
                    <span class="btn-icon">📂</span>
                    <span>Go to Status Page</span>
                </a>
                <span class="status-pill">Latest results available</span>
            </div>
        </div>

        <!-- Delete output panel (keeps your delete_output form & confirm) -->
        <div class="panel-card" style="border-color: rgba(239,68,68,0.6); background: rgba(127,29,29,0.5);">
            <div class="panel-title-row">
                <div class="panel-title">Reset / Delete Output</div>
                <span class="panel-tag" style="background:rgba(239,68,68,0.3); color:#fee2e2;">Danger Zone</span>
            </div>
            <div class="panel-sub">
                This will <strong>truncate all room_* tables</strong> in the output database and <strong>delete all seating_*.pdf</strong> files.
                Use this when you want to completely reset results before a new exam.
            </div>

            <form method="post" action="run_allocation.php" onsubmit="return confirmDeleteOutput();">
                <input type="hidden" name="delete_output" value="1">
                <div class="form-row">
                    <button type="submit" class="btn btn-danger">
                        🗑 Delete Output (truncate &amp; remove PDFs)
                    </button>
                    <button type="button" class="btn btn-ghost" onclick="window.location.href='index.php'">
                        ❌ Cancel
                    </button>
                </div>
                <div class="hint" style="margin-top:6px;">
                    This action is <strong>irreversible</strong>. Make sure you have downloaded any PDFs you need.
                </div>
            </form>
        </div>

    </section>

</div>

</body>
</html>
