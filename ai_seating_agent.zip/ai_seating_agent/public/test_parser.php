<?php
ini_set('display_errors',1); error_reporting(E_ALL);
require_once __DIR__ . '/../lib/utils.php';
require_once __DIR__ . '/../lib/ParserAgent.php';

// Change path to the actual uploaded file you want to test
$sample = __DIR__ . '/uploads/sample_students.csv'; // or the exact uploaded XLSX path

$parser = new ParserAgent();
$rows = $parser->run($sample);
echo "<h3>ParserAgent returned " . count($rows) . " rows</h3><pre>";
print_r($rows);
echo "</pre>";

echo "<h3>parse_regno() results</h3><pre>";
foreach ($rows as $r) {
    $p = parse_regno($r);
    echo htmlspecialchars($r) . "  =>  ";
    var_export($p);
    echo PHP_EOL;
}
echo "</pre>";
