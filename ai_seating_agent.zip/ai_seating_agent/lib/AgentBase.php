<?php


abstract class AgentBase {
  abstract public function run($input);
  public function rollback() {}
}
