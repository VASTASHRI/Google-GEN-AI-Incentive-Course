<?php
// public/debug_parse.php
ini_set('display_errors',1);
error_reporting(E_ALL);

require_once __DIR__ . '/../lib/utils.php';
require_once __DIR__ . '/../lib/ParserAgent.php';

echo "<h2>Debug Parser Output</h2>";

$uploadDirPublic = __DIR__ . '/uploads/';
$uploadDirProject = __DIR__ . '/../uploads/';

function show_files($path) {
    echo "<h3>Listing: " . htmlspecialchars($path) . "</h3>";
    if (!is_dir($path)) {
        echo "<p><b>Folder missing</b></p>";
        return;
    }
    $files = glob($path . '*');
    if (empty($files)) {
        echo "<p>No files found in this folder.</p>";
        return;
    }
    echo "<ul>";
    foreach ($files as $f) {
        echo "<li>" . htmlspecialchars(basename($f)) . " &nbsp; (size: " . filesize($f) . " bytes, ext: " . pathinfo($f, PATHINFO_EXTENSION) . ")</li>";
    }
    echo "</ul>";
}

show_files($uploadDirPublic);
show_files($uploadDirProject);

// choose which folder to debug (project-level preferred)
$folderToScan = is_dir($uploadDirProject) && count(glob($uploadDirProject . '*')) ? $uploadDirProject : $uploadDirPublic;
echo "<h3>Using folder: " . htmlspecialchars($folderToScan) . "</h3>";

$files = glob($folderToScan . '*');
if (empty($files)) {
    echo "<p>No files to parse.</p>";
    exit;
}

$parser = new ParserAgent();

foreach ($files as $filePath) {
    echo "<hr><h4>File: " . htmlspecialchars(basename($filePath)) . "</h4>";
    try {
        $rows = $parser->run($filePath);
        echo "<p>Parser returned <b>" . count($rows) . "</b> rows</p>";
        if (empty($rows)) {
            echo "<p><b>Empty parse result</b> — possible issues: wrong column, unreadable excel, or file corrupted.</p>";
        }
        echo "<table border='1' cellpadding='6' cellspacing='0'>";
        echo "<tr><th>#</th><th>Raw value</th><th>parse_regno()</th></tr>";
        $i = 0;
        foreach ($rows as $r) {
            $i++;
            $parsed = parse_regno($r);
            echo "<tr>";
            echo "<td>" . $i . "</td>";
            echo "<td>" . htmlspecialchars($r) . "</td>";
            echo "<td><pre>" . htmlspecialchars(var_export($parsed, true)) . "</pre></td>";
            echo "</tr>";
            if ($i >= 200) break; // don't flood the page
        }
        echo "</table>";
    } catch (Throwable $e) {
        echo "<p style='color:red;'>Parser error: " . htmlspecialchars($e->getMessage()) . "</p>";
    }
}
