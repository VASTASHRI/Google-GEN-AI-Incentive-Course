<?php


class DecisionAgent extends AgentBase {
    private $conflicts = [
        ['UIT','UCS'], ['UCE','UME'], ['UEE','UEC'], ['UBT','UBM']
    ];
    private $columnOrder = ['L3','R3','L2','R2','L1','R1'];
    private $colCapacity = 5;

    private function is_conflict($a, $b) {
        foreach ($this->conflicts as $p) {
            if (($a === $p[0] && $b === $p[1]) || ($a === $p[1] && $b === $p[0])) return true;
        }
        return false;
    }

    /**
     * Run allocation.
     *
     * @param array $input Expecting an array with:
     *                     - 'students' => array of students (each: ['regno'=>..., 'dept'=>..., 'year'=>...])
     *                     - 'roomNames' => array of room names (optional)
     * @return array allocations map: roomName => rows (each row is associative with keys L3,R3,L2,R2,L1,R1)
     */
    public function run($input)
{
    $students  = $input['students'] ?? [];
    $roomNames = $input['roomNames'] ?? [];

    // rest of your code...

        $allocations = [];
        $roomIndex = 0;
        $colCounts = array_fill_keys($this->columnOrder, 0);
        $currentRoomRows = [];
        // define which years prefer left (example)
        $leftYears = ['21','23']; // 21=4th, 22=3rd, 23=2nd, 24=1st (adjust if needed)

        // build queues
        $leftQueue = [];
        $rightQueue = [];
        foreach ($students as $s) {
            $year = isset($s['year']) ? $s['year'] : (isset($s[2]) ? $s[2] : null);
            if (in_array($year, $leftYears, true)) $leftQueue[] = $s;
            else $rightQueue[] = $s;
        }

        // Greedy fill across columns
        $colIdx = 0;
        while (!empty($leftQueue) || !empty($rightQueue)) {
            $col = $this->columnOrder[$colIdx % count($this->columnOrder)];
            $targetQueue = (strpos($col, 'L') === 0) ? 'left' : 'right';
            $placed = false;
            $value = null;

            if ($targetQueue === 'left' && !empty($leftQueue)) {
                $candidate = array_shift($leftQueue);
                $value = isset($candidate['regno']) ? $candidate['regno'] : (isset($candidate[0]) ? $candidate[0] : null);
                $placed = $value !== null;
            } elseif ($targetQueue === 'right' && !empty($rightQueue)) {
                $candidate = array_shift($rightQueue);
                $value = isset($candidate['regno']) ? $candidate['regno'] : (isset($candidate[0]) ? $candidate[0] : null);
                $placed = $value !== null;
            } else {
                // preferred queue empty -> take from the other side
                if (!empty($leftQueue)) {
                    $candidate = array_shift($leftQueue);
                    $value = isset($candidate['regno']) ? $candidate['regno'] : (isset($candidate[0]) ? $candidate[0] : null);
                    $placed = $value !== null;
                } elseif (!empty($rightQueue)) {
                    $candidate = array_shift($rightQueue);
                    $value = isset($candidate['regno']) ? $candidate['regno'] : (isset($candidate[0]) ? $candidate[0] : null);
                    $placed = $value !== null;
                }
            }

            if ($placed && $value !== null) {
                $rowIndex = $colCounts[$col];
                if (!isset($currentRoomRows[$rowIndex])) {
                    $currentRoomRows[$rowIndex] = array_fill_keys($this->columnOrder, null);
                }
                $currentRoomRows[$rowIndex][$col] = $value;
                $colCounts[$col] += 1;

                // check if room full
                $full = true;
                foreach ($colCounts as $c) {
                    if ($c < $this->colCapacity) { $full = false; break; }
                }
                if ($full) {
                    $rname = $roomNames[$roomIndex] ?? ('room_' . (201 + $roomIndex));
                    $allocations[$rname] = $currentRoomRows;
                    $roomIndex++;
                    $currentRoomRows = [];
                    $colCounts = array_fill_keys($this->columnOrder, 0);
                }
            }

            $colIdx++;
        }

        // commit any partially filled room
        if (!empty($currentRoomRows)) {
            $rname = $roomNames[$roomIndex] ?? ('room_' . (201 + $roomIndex));
            $allocations[$rname] = $currentRoomRows;
        }

        return $allocations;
    }
}
