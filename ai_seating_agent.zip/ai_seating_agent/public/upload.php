<?php
// upload.php
$config = include __DIR__ . '/../config.php';
$uploadDir = __DIR__ . '/../uploads/';
if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);

foreach ($_FILES['files']['tmp_name'] as $idx => $tmp) {
  $name = basename($_FILES['files']['name'][$idx]);
  move_uploaded_file($tmp, $uploadDir . $name);
}
header('Location: index.php');
