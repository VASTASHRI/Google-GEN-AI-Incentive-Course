<?php


class DBAgent extends AgentBase {
    /** @var \PDO */
  private $pdo;
  public function __construct($config) {
    $c = $config['db_output'];
    $this->pdo = new \PDO("mysql:host={$c['host']};dbname={$c['dbname']}", $c['user'], $c['pass']);
  }
  public function run($allocations) {
    foreach ($allocations as $room => $rows) {
      // ensure room table exists
      $this->ensureRoomTable($room);
      // truncate before insert or append? We'll truncate to be safe.
      $this->pdo->exec("TRUNCATE TABLE `$room`");
      // Insert each row
      $stmt = $this->pdo->prepare("INSERT INTO `$room` (L3,R3,L2,R2,L1,R1) VALUES (:L3,:R3,:L2,:R2,:L1,:R1)");
      foreach ($rows as $row) {
        $stmt->execute([
          ':L3' => $row['L3'] ?? null,
          ':R3' => $row['R3'] ?? null,
          ':L2' => $row['L2'] ?? null,
          ':R2' => $row['R2'] ?? null,
          ':L1' => $row['L1'] ?? null,
          ':R1' => $row['R1'] ?? null
        ]);
      }
    }
    return true;
  }
  private function ensureRoomTable($room) {
    $sql = "CREATE TABLE IF NOT EXISTS `$room` (
      id INT AUTO_INCREMENT PRIMARY KEY,
      L3 VARCHAR(50), R3 VARCHAR(50),
      L2 VARCHAR(50), R2 VARCHAR(50),
      L1 VARCHAR(50), R1 VARCHAR(50)
    )";
    $this->pdo->exec($sql);
  }
}
