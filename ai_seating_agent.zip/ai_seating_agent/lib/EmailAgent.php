<?php


use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

class EmailAgent extends AgentBase {
  private $config;
  public function __construct($config) { $this->config = $config['mail']; }
  public function run($studentEmails, $attachments=[]) {
    // $studentEmails: array of ['email'=>'','regno'=>'','room'=>'','seat'=>'']
    foreach ($studentEmails as $s) {
      $mail = new PHPMailer(true);
      try {
        $mail->isSMTP();
        $mail->Host = $this->config['smtp_host'];
        $mail->SMTPAuth = true;
        $mail->Username = $this->config['smtp_user'];
        $mail->Password = $this->config['smtp_pass'];
        $mail->SMTPSecure = 'tls';
        $mail->Port = $this->config['smtp_port'];
        $mail->setFrom($this->config['from_email'], $this->config['from_name']);
        $mail->addAddress($s['email']);
        $mail->Subject = 'Exam Seat Allotment';
        $mail->Body = "Dear Student,\nYour seat: {$s['seat']} in {$s['room']}. Regno: {$s['regno']}";
        foreach ($attachments as $f) $mail->addAttachment($f);
        $mail->send();
      } catch (Exception $e) {
        // log error
      }
    }
    return true;
  }
}
