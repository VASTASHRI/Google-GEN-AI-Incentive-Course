<?php
// lib/utils.php  (add or replace parse_regno in this file)

if (!function_exists('parse_regno')) {
    /**
     * Parse a register number and return ['year' => '21', 'dept' => 'UIT'] or null.
     * Accepts variants like:
     *   6176AC21UIT001
     *   6176ACUSE001
     *   6176AC-21-UIT-001
     *   6176AC21UIT
     *   6176AC21UIT 001
     */
    function parse_regno(string $s): ?array {
        $s = trim((string)$s);
        if ($s === '') return null;

        // Normalize: uppercase and remove non-alphanumeric except keep separation for readability
        $clean = strtoupper($s);
        // remove common separators but keep digits+letters together
        $clean = preg_replace('/[^A-Z0-9]/', '', $clean);

        // Known department codes (extend as needed)
        $validDepts = [
            'UIT','UCS','UCE','UEE','UBT','UBM','USE','UME','UAE','UUE' // add more codes if you have them
        ];

        // Common pattern: prefix (digits/letters) + 2-digit year + DEPT(2-4 letters) + serial (2-4 digits) optional
        // Example: 6176AC21UIT001  => captures year=21, dept=UIT
        if (preg_match('/\d{0,}[A-Z]*?(\d{2})([A-Z]{2,4})\d{0,4}$/', $clean, $m)) {
            $year = $m[1];
            $dept = $m[2];

            if (in_array($dept, $validDepts, true)) {
                return ['year' => $year, 'dept' => $dept];
            }
            // If dept not in allow-list but looks OK, optionally accept it:
            // return ['year'=>$year,'dept'=>$dept];
        }

        // fallback: find any 2-digit year and any 2-4 letter token afterward
        if (preg_match('/(\d{2})([A-Z]{2,4})/', $clean, $m2)) {
            $year = $m2[1];
            $dept = $m2[2];
            if (in_array($dept, $validDepts, true)) {
                return ['year' => $year, 'dept' => $dept];
            }
        }

        return null;
    }
}
